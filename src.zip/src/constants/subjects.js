// src/constants/subjects.js
export const SUBJECT_OPTIONS = [
  { value: 'Matematika', label: 'Matematika' },
  { value: 'Bahasa Indonesia', label: 'Bahasa Indonesia' },
  { value: 'Bahasa Inggris', label: 'Bahasa Inggris' },
  { value: 'IPA', label: 'IPA' },
  { value: 'IPS', label: 'IPS' },
  { value: 'PPKN', label: 'PPKN' },
  { value: 'PAI', label: 'Pendidikan Agama' },
  { value: 'PJOK', label: 'PJOK' },
  { value: 'Seni Budaya', label: 'Seni Budaya' },
]
